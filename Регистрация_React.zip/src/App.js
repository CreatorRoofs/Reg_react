import logo from './logo.svg';
import './App.css';
import Registr from './Registration/Registration';
function App() {
  return (
    <div className="App">
      <Registr/>
    </div>
  );
}

export default App;
