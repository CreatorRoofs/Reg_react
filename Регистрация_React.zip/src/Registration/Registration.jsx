import { useState } from "react"
const Registr = () => {
    const [show, setShow] = useState(false)
    const hadnleClick = () => {
        setShow(!show)
        show ? setShow(false) : setShow(true)
    }
    const [name, setName] = useState("")
    const [lastName, setLastName] = useState("")
    const [age, setAge] = useState("")
    const [selectValue, setSelectValue] = useState("")
    const [selectValue2, setSelectValue2] = useState("")
    const [selectValue3, setSelectValue3] = useState("")
    const [pass, setPass] = useState("")
    const [city, setCity] = useState("")
    const [hero, setHeroes] = useState("")
    const [fruit, setFruits] = useState("")
    const [check, setCheck] = useState("")
    const SavingData = () => {
        if (name == "" || lastName == "" || age == "" || selectValue == "0" || selectValue == "4"  && city == "" || selectValue2 == "0" || selectValue2 == "4" && hero == "" || selectValue3 == "0" || selectValue3 == "4"  && fruit == "" || pass.length == "" ) {
            return setCheck("Введены не все данные")
        } else if (pass.length < 5) {
            return setCheck("Пароль слишком короткий")
        }
        else { 
            return setCheck("Регистрация прошла успешно!")
        }
    }
    return(
        <div>
            <button style={{marginTop: "10px"}} onClick={hadnleClick}>{show ? "Скрыть форму регистрации" : "Показать форму регистрации"}</button>
                {show && (
                    <div style={{
                        display: "flex", 
                        flexDirection: "column", 
                        width: "200px", 
                        justifyContent: "center", 
                        alignItems: "center", 
                        margin: "auto", 
                        gap: "5px", 
                        border: "1px solid black",
                        borderRadius: "10px",
                        marginTop: "10px",
                        }}>
                        <label>
                            Имя
                            <input onChange={(e) => setName(e.target.value)}></input>
                        </label>
                        <label>
                            Фамилия
                            <input onChange={(e) => setLastName(e.target.value)}></input>
                        </label>
                        <label>
                            Возраст
                            <input onChange={(e) => setAge(e.target.value)}></input>
                        </label>
                        <label>
                            Город
                            <select style={{width: "175px", height:"22px"}} value={selectValue} onChange={(e) => setSelectValue(e.target.value)}>
                                <option value="0"></option>
                                <option value="1">Москва</option>
                                <option value="2">Санкт-Петербург</option>
                                <option value="3">Новосибирск</option>
                                <option value="4">Нет нужного варианта</option>
                            </select>
                              {selectValue == "4" && <input onChange={(e) => setCity(e.target.value)}/>}  
                        </label>
                        <label>
                            Любимый супергерой
                            <select style={{width: "175px", height:"22px"}} value={selectValue2} onChange={(e) => setSelectValue2(e.target.value)}>
                                <option value="0"></option>
                                <option value="1">Бэтмен</option>
                                <option value="2">Робен-гуд</option>
                                <option value="3">Гарри-Потер</option>
                                <option value="4">Нет нужного варианта</option>
                            </select>
                            {selectValue2 == "4" && <input onChange={(e) => setHeroes(e.target.value)}/>}  
                        </label>
                        <label>
                            Любимый фрукт
                            <select style={{width: "175px", height:"22px"}} value={selectValue3} onChange={(e) => setSelectValue3(e.target.value)}>
                                <option value="0"></option>
                                <option value="1">Банан</option>
                                <option value="2">Яблоко</option>
                                <option value="3">Киви</option>
                                <option value="4">Нет нужного варианта</option>
                            </select>
                              {selectValue3 == "4" && <input onChange={(e) => setFruits(e.target.value)}/>} 
                        </label>
                        <label>
                            Личный пароль
                            <input type="password" onChange={(e) => setPass(e.target.value)}></input>
                        </label>
                        <button style={{marginBottom: "10px", marginTop: "10px"}} onClick={SavingData}>Сохранить данные</button>
                        <div style={{marginBottom: "10px"}}>{check}</div>
                    </div>
                )}
                
        </div>
    )
}   

export default Registr